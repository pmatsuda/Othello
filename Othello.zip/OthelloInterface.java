/*
Author:  Pat Matsuda
Class;   ITK 275 - Java As A Second Language
Project = Othello game

Class description:
	This class will make the Othello game board visible
*/

public class OthelloInterface
{
	public static void main(String []args)
	{
			OthelloFrame frame = new OthelloFrame();
			frame.setVisible(true);
	}
}
