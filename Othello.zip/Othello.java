public class Othello
{
	public enum Pieces{Black, White, Empty};
	protected Pieces [][]boardArray;
	protected Pieces whoseTurn;

	public Othello()
	{
		boardArray = new Pieces[8][8];
		newGame();
	}

	public String getWhoseTurn()
	{
		if (whoseTurn == Pieces.White)
			return "White";
		else
			return "Black";
	}

	public String pieceAt(int x, int y)
	{
		if (boardArray[x][y] == Pieces.White)
			return "White";
		else if (boardArray[x][y] == Pieces.Black)
			return "Black";
		else
			return "Empty";
	}

	public void pass()
	{
		if (whoseTurn == Pieces.White)
			whoseTurn = Pieces.Black;
		else
			whoseTurn = Pieces.White;
	}

	private boolean isLegal(int x, int y)
	{
		if (boardArray[x][y] != Pieces.Empty)
			return false;

		int i;

		//check North (y--)
		if (y>1) //Placing in 2 Northmost rows will be invalid north
		{
			//Only proceed if one space north is opposite color
			if (boardArray[x][y-1] != whoseTurn && boardArray[x][y-1] != Pieces.Empty)
			{
				//start searching for current color two spaces away
				for (i=y-2;i>=0;i--)
				{
					if (boardArray[x][i] == whoseTurn)
						return true;
					if (boardArray[x][i] == Pieces.Empty)
						break; //North is not valid
				}
			}
		}
		//North is not valid

		//check NorthEast (y-- x++)
		if (y>1 && x <6) //Placing in 2 Eastmost columns or 2 Northmost rows will be invalid northeast
		{
			//Only proceed if one space northeast is opposite color
			if (boardArray[x+1][y-1] != whoseTurn && boardArray[x+1][y-1] != Pieces.Empty)
			{
				//keep from falling off of the board
				i = 2;
				while (x+i<=7 && y-i>=0)
				{
					if (boardArray[x+i][y-i] == whoseTurn)
						return true;
					if (boardArray[x+i][y-i] == Pieces.Empty)
						break; //Northeast is not valid
					i++;
				}
			}
		}
		//Northeast is not valid

		//check East (x++)
		if (x<6) //Placing in 2 Eastmost columns will be invalid East
		{
			if (boardArray[x+1][y] != whoseTurn && boardArray[x+1][y] != Pieces.Empty)
			{
				for (i=x+2;i<=7;i++)
				{
					if (boardArray[i][y] == whoseTurn)
						return true;
					if (boardArray[i][y] == Pieces.Empty)
						break; //East is not valid
				}
			}
		}
		//East is not valid

		//check SouthEast (x++ y++)
		if (x<6 && y<6)
		{
			if (boardArray[x+1][y+1] != whoseTurn && boardArray[x+1][y+1] != Pieces.Empty)
			{
				i = 2;
				while (x+i<=7 && y+i<=7)
				{
					if (boardArray[x+i][y+i] == whoseTurn)
						return true;
					if (boardArray[x+i][y+i] == Pieces.Empty)
						break; //Southeast is not valid
					i++;
				}
			}
		}
		//Southeast is not valid

		//check South (y++)
		if (y<6)
		{
			if (boardArray[x][y+1] != whoseTurn && boardArray[x][y+1] != Pieces.Empty)
			{
				for (i=y+2;i<=7;i++)
				{
					if (boardArray[x][i] == whoseTurn)
						return true;
					if (boardArray[x][i] == Pieces.Empty)
						break; //South is not valid
				}
			}
		}
		//South is not valid

		//check SouthWest (y++ x--)
		if (x>1 && y<6)
		{
			if (boardArray[x-1][y+1] != whoseTurn && boardArray[x-1][y+1] != Pieces.Empty)
			{
				i = 2;
				while (x-i>=0 && y+i<=7)
				{
					if (boardArray[x-i][y+i] == whoseTurn)
						return true;
					if (boardArray[x-i][y+i] == Pieces.Empty)
						break; //SouthWest is not valid
					i++;
				}
			}
		}
		//SouthWest is not valid

		//check West (x--)
		if (x>1)
		{
			if (boardArray[x-1][y] != whoseTurn && boardArray[x-1][y] != Pieces.Empty)
			{
				for (i=x-2;i>=0;i--)
				{
					if (boardArray[i][y] == whoseTurn)
						return true;
					if (boardArray[i][y] == Pieces.Empty)
						break; //West is not valid
				}
			}
		}
		//West is not valid

		//check NorthWest (x-- y--)
		if (x>1 && y>1)
		{
			if (boardArray[x-1][y-1] != whoseTurn && boardArray[x-1][y-1] != Pieces.Empty)
			{
				i = 2;
				while (x-i>=0 && y-i>=0)
				{
					if (boardArray[x-i][y-i] == whoseTurn)
						return true;
					if (boardArray[x-i][y-i] == Pieces.Empty)
						break; //NorthWest is not valid
					i++;
				}
			}
		}
		//NorthWest is not valid

		return false;
	}

	public boolean playAPiece(int x, int y)
	{
		if (!isLegal(x,y))
			return false;

		boardArray[x][y] = whoseTurn;

		int i;

		//check North (y--)
		if (y>1) //Placing in 2 Northmost rows will be invalid north
		{
			//Only proceed if one space north is opposite color
			if (boardArray[x][y-1] != whoseTurn && boardArray[x][y-1] != Pieces.Empty)
			{
				//start searching for current color two spaces away
				for (i=y-2;i>=0;i--)
				{
					if (boardArray[x][i] == whoseTurn)
					{
						for (i++;i<y;i++) //traverse back North
							boardArray[x][i] = whoseTurn;
						break; //all pieces North have been switched
					}
					if (boardArray[x][i] == Pieces.Empty)
						break; //North is not valid
				}
			}
		}

		//check NorthEast (y-- x++)
		if (y>1 && x <6) //Placing in 2 Eastmost columns or 2 Northmost rows will be invalid northeast
		{
			//Only proceed if one space northeast is opposite color
			if (boardArray[x+1][y-1] != whoseTurn && boardArray[x+1][y-1] != Pieces.Empty)
			{
				//keep from falling off of the board
				i = 2;
				while (x+i<=7 && y-i>=0)
				{
					if (boardArray[x+i][y-i] == whoseTurn)
					{
						for (i--;i>0;i--)
							boardArray[x+i][y-i] = whoseTurn;
						break;
					}
					if (boardArray[x+i][y-i] == Pieces.Empty)
						break; //Northeast is not valid
					i++;
				}
			}
		}

		//check East (x++)
		if (x<6) //Placing in 2 Eastmost columns will be invalid East
		{
			if (boardArray[x+1][y] != whoseTurn && boardArray[x+1][y] != Pieces.Empty)
			{
				for (i=x+2;i<=7;i++)
				{
					if (boardArray[i][y] == whoseTurn)
					{
						for (i--;i>x;i--)
							boardArray[i][y] = whoseTurn;
						break;
					}
					if (boardArray[i][y] == Pieces.Empty)
						break; //East is not valid
				}
			}
		}

		//check SouthEast (x++ y++)
		if (x<6 && y<6)
		{
			if (boardArray[x+1][y+1] != whoseTurn && boardArray[x+1][y+1] != Pieces.Empty)
			{
				i = 2;
				while (x+i<=7 && y+i<=7)
				{
					if (boardArray[x+i][y+i] == whoseTurn)
					{
						for (i--;i>0;i--)
							boardArray[x+i][y+i] = whoseTurn;
						break;
					}
					if (boardArray[x+i][y+i] == Pieces.Empty)
						break; //Southeast is not valid
					i++;
				}
			}
		}

		//check South (y++)
		if (y<6)
		{
			if (boardArray[x][y+1] != whoseTurn && boardArray[x][y+1] != Pieces.Empty)
			{
				for (i=y+2;i<=7;i++)
				{
					if (boardArray[x][i] == whoseTurn)
					{
						for (i--;i>y;i--)
							boardArray[x][i] = whoseTurn;
						break;
					}
					if (boardArray[x][i] == Pieces.Empty)
						break; //South is not valid
				}
			}
		}

		//check SouthWest (y++ x--)
		if (x>1 && y<6)
		{
			if (boardArray[x-1][y+1] != whoseTurn && boardArray[x-1][y+1] != Pieces.Empty)
			{
				i = 2;
				while (x-i>=0 && y+i<=7)
				{
					if (boardArray[x-i][y+i] == whoseTurn)
					{
						for (i--;i>0;i--)
							boardArray[x-i][y+i] = whoseTurn;
						break;
					}
					if (boardArray[x-i][y+i] == Pieces.Empty)
						break; //SouthWest is not valid
					i++;
				}
			}
		}

		//check West (x--)
		if (x>1)
		{
			if (boardArray[x-1][y] != whoseTurn && boardArray[x-1][y] != Pieces.Empty)
			{
				for (i=x-2;i>=0;i--)
				{
					if (boardArray[i][y] == whoseTurn)
					{
						for (i++;i<x;i++)
							boardArray[i][y] = whoseTurn;
						break;
					}
					if (boardArray[i][y] == Pieces.Empty)
						break; //West is not valid
				}
			}
		}

		//check NorthWest (x-- y--)
		if (x>1 && y>1)
		{
			if (boardArray[x-1][y-1] != whoseTurn && boardArray[x-1][y-1] != Pieces.Empty)
			{
				i = 2;
				while (x-i>=0 && y-i>=0)
				{
					if (boardArray[x-i][y-i] == whoseTurn)
					{
						for (i--;i>0;i--)
							boardArray[x-i][y-i] = whoseTurn;
						break;
					}
					if (boardArray[x-i][y-i] == Pieces.Empty)
						break; //NorthWest is not valid
					i++;
				}
			}
		}

		pass();
		return true;
	}

	public void newGame()
	{
		for (int i=0;i<=7;i++)
			for (int j=0;j<=7;j++)
				boardArray[i][j] = Pieces.Empty;
		boardArray[3][3] = Pieces.White;
		boardArray[4][4] = Pieces.White;
		boardArray[3][4] = Pieces.Black;
		boardArray[4][3] = Pieces.Black;
		whoseTurn = Pieces.White;
	}

	public boolean whiteHasMove()
	{
		Pieces holdTurn = whoseTurn;
		whoseTurn = Pieces.White;
		boolean hasMove = hasAValidMove();
		whoseTurn = holdTurn;
		return hasMove;
	}

	public boolean blackHasMove()
	{
		Pieces holdTurn = whoseTurn;
		whoseTurn = Pieces.Black;
		boolean hasMove = hasAValidMove();
		whoseTurn = holdTurn;
		return hasMove;
	}

	public boolean hasAValidMove()
	{
		for (int x=0;x<=7;x++)
			for (int y=0;y<=7;y++)
				if (isLegal(x,y))
					return true;
		return false;
	}

	public int blackPieces()
	{
		int blackCount = 0;
		for (Pieces[] rows:boardArray)
			for (Pieces piece: rows)
				if (piece == Pieces.Black)
					blackCount++;
		return blackCount;
	}

	public int whitePieces()
	{
		int whiteCount = 0;
		for (Pieces[] rows:boardArray)
			for (Pieces piece: rows)
				if (piece == Pieces.White)
					whiteCount++;
		return whiteCount;
	}
}